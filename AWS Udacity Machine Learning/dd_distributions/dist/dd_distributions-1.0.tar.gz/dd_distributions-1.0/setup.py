from setuptools import setup

setup(name='dd_distributions',
      version='1.0',
      description='Statistical distributions',
      packages=['dd_distributions'],
      author = 'Oludare Oluwajuyitan',
      author_email = 'ddrightnow@yahoo.com',
      zip_safe=False)
