from setuptools import setup

setup(name='ddbinom_distributions',
      version='1.0',
      description='Statistical distributions',
      packages=['ddbinom_distributions'],
      author = 'Oludare Oluwajuyitan',
      author_email = 'ddrightnow@yahoo.com',
      zip_safe=False)
